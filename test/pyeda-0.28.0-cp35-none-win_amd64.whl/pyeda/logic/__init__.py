"""
PyEDA Logic
"""

