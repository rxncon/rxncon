"""
Python EDA Package
"""

__version__ = "0.28.0"

